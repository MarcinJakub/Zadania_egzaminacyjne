let btnDodawanie = document.querySelector('#dodawanie');
let btnOdejmowanie = document.querySelector('#odejmowanie');
let btnMnozenie = document.querySelector('#mnozenie');
let btnDzielenie = document.querySelector('#dzielenie');
let btnPotegowanie = document.querySelector('#potegowanie');
let wyswietl = document.querySelector('#wynik');

let wynik = 0;

btnDodawanie.addEventListener("click", function(){
    a = parseInt(document.querySelector('#a').value);
    b = parseInt(document.querySelector('#b').value);
    wynik = a + b;
    wyswietl.innerHTML = "Wynik: " + wynik;
})

btnOdejmowanie.addEventListener("click", function (){
    a = parseInt(document.querySelector('#a').value);
    b = parseInt(document.querySelector('#b').value);
    wynik = a - b;
    wyswietl.innerHTML = "Wynik: " + wynik;
})

btnMnozenie.addEventListener("click", function(){
    a = parseInt(document.querySelector('#a').value);
    b = parseInt(document.querySelector('#b').value);
    wynik = a * b;
    wyswietl.innerHTML = "Wynik: " + wynik;
})

btnDzielenie.addEventListener("click", function(){
    a = parseInt(document.querySelector('#a').value);
    b = parseInt(document.querySelector('#b').value);
    wynik = a / b;
    wyswietl.innerHTML = "Wynik: " + wynik;
})

btnPotegowanie.addEventListener("click", function(){
    a = parseInt(document.querySelector('#a').value);
    b = parseInt(document.querySelector('#b').value);
    wynik = Math.pow(a, b);
    wyswietl.innerHTML = "Wynik: " + wynik;
})
